# TPC.FTBL × SHEPD Website

Open `index.html` in a browser to preview the site.

## Publish it
Upload the entire folder to any static hosting service such as GitHub Pages, Netlify, or Vercel.

The Telegram button is already connected to:
https://t.me/pfpservicetpcftblshepdteasers
